<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to the login page
    header('Location: login.php');
    exit();
}
?>

<?php
// Include database connection
include '../includes/connection.php';

// Fetch all records from the 'blog' table joined with the 'category' table to get the category name
$query = "SELECT blog.*, category.category_name FROM blog JOIN category ON blog.category = category.id";
$result = mysqli_query($connection, $query);

// Fetch all category for the dropdown
$category_query = "SELECT * FROM category";
$category_result = mysqli_query($connection, $category_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
    /* Prevent description overflow */
    .table td.text-truncate {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    /* Make images uniform */
    .table img {
        object-fit: cover;
        border-radius: 4px;
    }

    /* Add hover effect for rows */
    .table-hover tbody tr:hover {
        background-color: #f1f1f1;
    }

    /* Adjust button spacing */
    .table td button {
        margin-right: 5px;
    }
    </style>
    <style>
    #body {
        background-color: #f8f9fa;
        width: calc(100% - 250px);
        margin-left: 250px;
        margin-top: 100px;
    }
    </style>
</head>
<?php include 'nav.php' ?>

<body id="body">
    <div class="container mt-5">
        <h2 class="text-center">Admin Dashboard</h2>
        <div class="text-right mb-3">
            <button class="btn btn-primary" data-toggle="modal" data-target="#addModal">Add New Record</button>
        </div>
        <div class="table-responsive">
            <!-- Add responsiveness -->
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <!-- Dark header -->
                    <tr>
                        <th>ID</th>
                        <th>Category</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Photo</th>
                        <th>Target</th>
                        <th>Raised</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['category_name']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td class="text-truncate" style="max-width: 150px;">
                            <?php echo $row['description']; ?>
                        </td>
                        <td>
                            <img src="../images/<?php echo $row['photo']; ?>" alt="Photo" class="img-thumbnail"
                                style="width: 50px; height: 50px;">
                        </td>
                        <td><?php echo $row['target']; ?></td>
                        <td><?php echo $row['raised']; ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm editBtn"
                                data-id="<?php echo $row['id']; ?>">Edit</button>
                            <button class="btn btn-danger btn-sm deleteBtn"
                                data-id="<?php echo $row['id']; ?>">Delete</button>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Record</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST" action="add_record.php" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Category</label>
                            <select name="category" class="form-control" required>
                                <option value="">Select a Category</option>
                                <?php while ($category = mysqli_fetch_assoc($category_result)) { ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo $category['category_name']; ?>
                                </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter name" required>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Photo</label>
                            <input type="file" name="photo" class="form-control-file" required>
                        </div>
                        <div class="form-group">
                            <label>Target</label>
                            <input type="number" name="target" class="form-control" placeholder="Enter target amount"
                                required>
                        </div>
                        <div class="form-group">
                            <label>Raised</label>
                            <input type="number" name="raised" class="form-control" placeholder="Enter raised amount"
                                required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Record</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST" action="edit_record.php" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="id"> <!-- Hidden ID field -->
                        <div class="form-group">
                            <label>Category</label>
                            <select name="category" class="form-control" required>
                                <?php 
                                    // Reset the category result to show all category again in the edit modal
                                    mysqli_data_seek($category_result, 0); 
                                    while ($category = mysqli_fetch_assoc($category_result)) { ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo $category['category_name']; ?>
                                </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Edit name" required>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="3" required></textarea>
                        </div>

                        <div class="form-group">
                            <label>Change Photo (Optional)</label>
                            <input type="file" name="photo" class="form-control-file">
                        </div>
                        <div class="form-group">
                            <label>Target</label>
                            <input type="number" name="target" class="form-control" placeholder="Edit target amount"
                                required>
                        </div>
                        <div class="form-group">
                            <label>Raised</label>
                            <input type="number" name="raised" class="form-control" placeholder="Edit raised amount"
                                required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include 'scripts.php' ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
<?php include 'sidebar.php' ?>
<script>
$(document).on('click', '.deleteBtn', function() {
    const id = $(this).data('id');

    if (confirm('Are you sure you want to delete this record?')) {
        $.ajax({
            url: 'delete_record.php',
            type: 'POST',
            data: {
                id: id
            },
            success: function() {
                alert('Record deleted successfully!');
                location.reload(); // Reload the page to reflect changes
            }
        });
    }
});

$(document).on('click', '.editBtn', function() {
    const id = $(this).data('id'); // Get the ID from data-id attribute

    // Fetch record data
    $.ajax({
        url: 'get_record.php',
        type: 'POST',
        data: {
            id: id
        },
        success: function(response) {
            const record = JSON.parse(response);

            // Check if there is an error
            if (record.error) {
                alert(record.error);
                return;
            }

            // Populate the modal fields with the fetched data
            $('#editModal input[name="id"]').val(record.id);
            $('#editModal select[name="category"]').val(record.category);
            $('#editModal input[name="name"]').val(record.name);
            $('#editModal textarea[name="description"]').val(record.description);
            $('#editModal input[name="target"]').val(record.target);
            $('#editModal input[name="raised"]').val(record.raised);

            // Display the existing photo in the modal if it exists
            if (record.photo) {
                $('#editModal').find('.modal-body').prepend(
                    '<p><strong>Current Photo:</strong></p><img src="../images/' + record
                    .photo +
                    '" alt="Current Photo" class="img-thumbnail" style="width: 100px; height: 100px;">'
                );
            }

            // Show the modal
            $('#editModal').modal('show');
        },
        error: function() {
            alert('Failed to fetch record data.');
        }
    });
});
</script>

<script>
tinymce.init({
    selector: 'textarea', // Targets all textareas
    plugins: 'lists link image table code',
    toolbar: 'undo redo | bold italic underline | bullist numlist | alignleft aligncenter alignright alignjustify | link image table | code',
    menubar: false, // Hides the menubar for a cleaner interface
    branding: false, // Removes TinyMCE branding
    height: 300, // Sets a consistent editor height
    content_css: 'default', // Ensures content styles match TinyMCE's defaults
    setup: function(editor) {
        editor.on('init', function() {
            console.log('TinyMCE is ready!');
        });
    }
});
</script>
<!-- jQuery and Bootstrap JS inclusion -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
// Custom script to close the modal when the Close button is clicked
$(document).ready(function() {
    // Close the modal when the Close button is clicked
    $('.close').on('click', function() {
        $('#editEventModal').modal('hide'); // Close the modal
    });
});
</script>

</html>
