<?php
require '../includes/connection.php';
$stmt = $pdo->query('SELECT * FROM payments LIMIT 1');
print_r($stmt->fetch(PDO::FETCH_ASSOC));
?>
