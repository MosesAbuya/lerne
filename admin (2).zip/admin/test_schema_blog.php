<?php
require '../includes/connection.php';
$stmt = $pdo->query('SHOW COLUMNS FROM blog');
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
