<?php
require '../includes/connection.php';
$stmt = $pdo->query('SELECT * FROM blog');
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
