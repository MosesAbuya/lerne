<?php
require '../includes/connection.php';
$stmt = $pdo->query('SELECT COUNT(*) FROM products');
echo $stmt->fetchColumn();
?>
