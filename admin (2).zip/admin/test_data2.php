<?php
require '../includes/connection.php';
$stmt = $pdo->query('SELECT * FROM products ORDER BY id DESC');
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
